
clear;
rng(123);
snr_values = -3;
Ts1 = 1e-3;  % Tiempo de muestreo (sample time)
bit_counts = 10e4;  % Números de bits deseados
BER = zeros(length(snr_values),length(bit_counts));
I_values = zeros(size(bit_counts));


SNR_V = snr_values(s);
    N_bits = bit_counts(k);
    stop_time = bit_counts(k) * Ts1;

    % Fuente binaria aleatoria
    a = rand(1, N_bits) < 0.5;
    
    % Añadir ruido AWGN directamente (sin modulación por ahora)
    a_double = double(a);  % Convertir a tipo double
    r = awgn(a_double, SNR_V, 'measured');

    b = r > 0.5;

    % Contadores
    C00 = sum(a == 0 & b == 0);
    C01 = sum(a == 0 & b == 1);
    C10 = sum(a == 1 & b == 0);
    C11 = sum(a == 1 & b == 1);

    % Totales
    C0 = C00 + C01;
    C1 = C10 + C11;

    % Matriz de probabilidad Pab
    Pab = [
        C00 / C0, C01 / C0;
        C10 / C1, C11 / C1
    ];
    
   

    Pa = [C0/(C0 + C1), C1/(C0 + C1)];
    Pb = Pa * Pab;

    % Matriz de probabilidad inversa Pba
    Pba = zeros(2, 2);
    for a_val = [0, 1]
        I = a_val + 1;
        for b_val = [0, 1]
            J = b_val + 1;
            if Pb(J) > 0
                Pba(I, J) = Pa(I) * Pab(I, J) / Pb(J);
            else
                Pba(I, J) = 0;
            end
        end
    end

    % Información promedio de la entrada H(A)
    Ha = 0;
    for i=1:length(Pa)
        Ha = Ha + (-1)*Pa(i)*log2(Pa(i));
    end

    % Información promedio de la salida H(B)
    Hb = 0;
    for i=1:length(Pb)
        Hb = Hb + (-1)*Pb(i)*log2(Pb(i));
    end

    % Ruido asociado a las ocurrencias de [0,1] en B, 
    % no generadas por la fuente A
    [filas, columnas] = size(Pab);
    
    Na = zeros(2,1);
    for i=1:filas
        for j=1:columnas
            if Pab(i,j) > 0
                Na(i) = Na(i) + (-1)*Pab(i,j)*log2(Pab(i,j));
            end
        end
    end
    
    N_total = 0;
    for i=1:length(Na)
        N_total = N_total + Na(i)*Pa(i);
    end
    
    % Equivocidad asociada a las ocurrencias de [0,1] en A,
    % que no llegan a la fuente B
    [filas, columnas] = size(Pab);
    
    Eb = zeros(1,2);
    for i=1:filas
        for j=1:columnas
            if Pba(i,j) > 0
                Eb(j) = Eb(j) + (-1)*Pba(i,j)*log2(Pba(i,j));
            end
        end
    end
    
    E_total = 0;
    for j=1:length(Eb)
        E_total = E_total + Eb(j)*Pb(j);
    end

    Iab_E = Ha - E_total;
    Iab_N = Hb - N_total;

    BER(k)= (C01 + C10)/(C0 + C1);
    I_values(k) = Iab_E;

 % Visualización de datos
disp('Matriz de probabilidad Pab:');
disp(Pab);

disp('Matriz de probabilidad Pba:');
disp(Pba);

disp('Probabilidad Pa:');
disp(Pa);

disp('Probabilidad Pb:');
disp(Pb);

disp('Información promedio H(A):');
disp(Ha);

disp('Información promedio H(B):');
disp(Hb);

disp('Ruido N(ai):');
disp(Na);

disp('Ruido total:');
disp(N_total);

disp('Equivocidad E(bj):');
disp(Eb);

disp('Equivocidad total:');
disp(E_total);

disp('Información mutua dado E:');
disp(Iab_E);

disp('Información mutua dado N:');
disp(Iab_N);

disp('Tasa/rata de errores de bit (BER):');
disp(BER);
