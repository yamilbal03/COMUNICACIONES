/* Include files */

#include "Teoria_parte1_cgxe.h"
#include "m_9tkfuFOKiXJGJ3ZKJ0u9KB.h"

unsigned int cgxe_Teoria_parte1_method_dispatcher(SimStruct* S, int_T method,
  void* data)
{
  if (ssGetChecksum0(S) == 3952305121 &&
      ssGetChecksum1(S) == 1081508986 &&
      ssGetChecksum2(S) == 192124046 &&
      ssGetChecksum3(S) == 2713724425) {
    method_dispatcher_9tkfuFOKiXJGJ3ZKJ0u9KB(S, method, data);
    return 1;
  }

  return 0;
}
