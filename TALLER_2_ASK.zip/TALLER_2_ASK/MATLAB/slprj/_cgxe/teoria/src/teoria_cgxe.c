/* Include files */

#include "teoria_cgxe.h"
#include "m_LsLoJRTEYWpriNF8H2nkNE.h"

unsigned int cgxe_teoria_method_dispatcher(SimStruct* S, int_T method, void
  * data)
{
  if (ssGetChecksum0(S) == 416170163 &&
      ssGetChecksum1(S) == 3133719601 &&
      ssGetChecksum2(S) == 1119429596 &&
      ssGetChecksum3(S) == 2214537403) {
    method_dispatcher_LsLoJRTEYWpriNF8H2nkNE(S, method, data);
    return 1;
  }

  return 0;
}
