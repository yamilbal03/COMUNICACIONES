% SIMULINK + MATLAB
%clear;

snr_values = 5;
Ts1 = 1e-3;  % Tiempo fijo de simulación (en segundos)
bit_counts = 20e4;
% BER = zeros(size(bit_counts));
I_values = zeros(size(bit_counts));


% for s = 1:length(snr_values)
    % SNR_V = snr_values(s);

    % for k = 1:length(bit_counts)
        % N_bits = bit_counts(k);
        stop_time = bit_counts * Ts1;


        % Crear objeto de simulación eficiente
        simIn = Simulink.SimulationInput("Teoria_parte1");
        simIn = simIn.setVariable("snr_v", snr_values);
        simIn = simIn.setVariable("Ts1", Ts1);
        simIn = simIn.setModelParameter("StopTime", num2str(stop_time));

        % Ejecutar simulación
        simOut = sim(simIn);

        % Obtener resultados
        C00 = simOut.C00(end);
        C01 = simOut.C01(end);
        C10 = simOut.C10(end);
        C11 = simOut.C11(end);

        C0 = C00 + C01;
        C1 = C10 + C11;
        Pa = [C0/(C0 + C1), C1/(C0 + C1)];

        Pab = [
            C00 / C0, C01 / C0;
            C10 / C1, C11 / C1
        ];

       
        Pb = Pa * Pab;

        % Pba
        Pba = zeros(2, 2);
        for a = 1:2
            for b = 1:2
                if Pb(b) > 0
                    Pba(a,b) = Pa(a) * Pab(a,b) / Pb(b);
                end
            end
        end

        % Información promedio de la entrada H(A)
        Ha = 0;
        for i=1:length(Pa)
            Ha = Ha + (-1)*Pa(i)*log2(Pa(i));
        end

        % Información promedio de la salida H(B)
        Hb = 0;
        for i=1:length(Pb)
            Hb = Hb + (-1)*Pb(i)*log2(Pb(i));
        end

        % Ruido asociado a las ocurrencias de [0,1] en B, 
        % no generadas por la fuente A
        [filas, columnas] = size(Pab);
        
        Na = zeros(2,1);
        for i=1:filas
            for j=1:columnas
                if Pab(i,j) > 0
                    Na(i) = Na(i) + (-1)*Pab(i,j)*log2(Pab(i,j));
                end
            end
        end
        
        N_total = 0;
        for i=1:length(Na)
            N_total = N_total + Na(i)*Pa(i);
        end
        
        % Equivocidad asociada a las ocurrencias de [0,1] en A,
        % que no llegan a la fuente B
        [filas, columnas] = size(Pab);
        
        Eb = zeros(1,2);
        for i=1:filas
            for j=1:columnas
                if Pba(i,j) > 0
                    Eb(j) = Eb(j) + (-1)*Pba(i,j)*log2(Pba(i,j));
                end
            end
        end
        
        E_total = 0;
        for j=1:length(Eb)
            E_total = E_total + Eb(j)*Pb(j);
        end

        Iab_E = Ha - E_total;
        Iab_N = Hb - N_total;
        BER = (C01 + C10)/(C0 + C1);
        
        % BER(s,k) = (C01 + C10)/(C0 + C1);
        % I_values(k) = Iab_E;
    % end

    % % Graficar
    % figure;
    % bit_counts_e4 = bit_counts * 1e-4;
    % p = polyfit(bit_counts_e4, I_values, 1);
    % I_vfit = polyval(p, bit_counts_e4);
    % grafica = plot(bit_counts_e4, I_values, '-ob', bit_counts_e4, I_vfit, '-r');
    % grafica(1).LineWidth = 0.5;
    % grafica(2).LineWidth = 2;
    % 
    % xlabel('Número de bits transmitidos (10^4)');
    % ylabel('Información mutua I(A;B)');
    % title(['I(A;B) vs N° de bits, SNR = ', num2str(SNR_V), ' dB']);
    % grid on;
% end

    
% Visualización de datos
disp('Matriz de probabilidad Pab:');
disp(Pab);

disp('Matriz de probabilidad Pba:');
disp(Pba);

disp('Probabilidad Pa:');
disp(Pa);

disp('Probabilidad Pb:');
disp(Pb);

disp('Información promedio H(A):');
disp(Ha);

disp('Información promedio H(B):');
disp(Hb);

disp('Ruido N(ai):');
disp(Na);

disp('Ruido total:');
disp(N_total);

disp('Equivocidad E(bj):');
disp(Eb);

disp('Equivocidad total:');
disp(E_total);

disp('Información mutua dado E:');
disp(Iab_E);

disp('Información mutua dado N:');
disp(Iab_N);

disp('Tasa/rata de errores de bit (BER):');
disp(BER);
